# xlm-roberta-base-fine-tuning-text-classifier-lux/__init__.py
from .text_classification_model import TextClassificationModel
